package lab2;

import java.util.Arrays;
public class question3 {

	public static void main(String[] args) {
		String []element = {"yellow","green","pink","blue"};
		int len = element.length;
		for (int i = element.length - 1; i >= 0; i--) {
            System.out.println(element[i]);
        }
	}

}

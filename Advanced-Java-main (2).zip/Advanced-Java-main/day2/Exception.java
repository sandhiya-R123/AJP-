package example2;

public class Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text  = null;
		int length = text.length();
		System.out.println(length);

	}

}

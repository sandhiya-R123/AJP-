package example4;

public class sample {
	public void name() {
		System.out.println("name");
	}

}

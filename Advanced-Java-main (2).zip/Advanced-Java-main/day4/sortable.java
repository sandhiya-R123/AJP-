package example4;
import java.util.List;

	

	public interface sortable <T>{
	   void sort(List<T> items);
	}



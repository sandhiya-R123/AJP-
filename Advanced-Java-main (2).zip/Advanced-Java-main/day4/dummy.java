package example4;

public class dummy extends sample {
	public static void main(String[] args) {
		sample s = new sample();
		s.name();

	}


}



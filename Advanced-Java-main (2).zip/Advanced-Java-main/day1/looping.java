package example1;

public class looping {

	public static void main(String[] args) {
//		sequential
//		decision
//		looping
		

	}

}

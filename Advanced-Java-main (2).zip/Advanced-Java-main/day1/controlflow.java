package example1;

public class controlflow {

	public static void main(String[] args) {
//		sequential
//		decision making
//		looping
		
		// 1 to 30 odd numbers
		for(int i = 1;i<=30;i++) {
			
			if(!(i%2 == 0)){
				System.out.println(i);
			}
		}

	}

}
